
"""Generate six large inputs and compare Trie, BST, and dictionary timings."""

import csv
import os
import random
from time import perf_counter

import matplotlib.pyplot as plt

from main import INDEX_CLASSES, build_index, write_index


# Required number of distinct words in each input file
COUNTS = [1000, 5000, 10000, 50000, 100000, 500000]

# Every input file must contain 1,100,000 word occurrences
TOTAL_WORDS = 1_100_000

# Folder to store input files and index output files
OUT_DIR = "benchmark_data"


def make_word(number):
    """Create a word such as word000001."""
    return "word" + str(number).zfill(6)


def generate_file(filename, distinct_count):
    """Generate a file with exactly the required distinct word count."""

    rng = random.Random(42 + distinct_count)

    # Create the required number of distinct words
    words = [make_word(i) for i in range(distinct_count)]

    # Put every word into the file at least once
    all_words = words.copy()

    # Add random words until the total reaches 1,100,000
    for _ in range(TOTAL_WORDS - distinct_count):
        all_words.append(rng.choice(words))

    # Randomize the order of all words
    rng.shuffle(all_words)

    # Write 1,000 words per line
    with open(filename, "w", encoding="ascii") as file:
        for start in range(0, TOTAL_WORDS, 1000):
            batch = all_words[start:start + 1000]
            file.write(" ".join(batch) + "\n")


def main():
    # Create the output folder if it does not exist
    os.makedirs(OUT_DIR, exist_ok=True)

    rows = []
    rng = random.Random(42)

    # Test all six distinct-word counts
    for count in COUNTS:
        input_file = f"{OUT_DIR}/words_{count}.txt"

        print("\nGenerating:", input_file)
        generate_file(input_file, count)

        # Prepare 100,000 words for the search test
        possible_words = [make_word(i) for i in range(count)]
        searches = [
            rng.choice(possible_words) for _ in range(100_000)
        ]

        # Test Trie, BST, and dictionary
        for method, cls in INDEX_CLASSES.items():
            print("Testing", method, "with", count, "distinct words")

            index = cls()

            # Measure construction time
            start = perf_counter()
            build_index(input_file, index)
            build_seconds = perf_counter() - start

            # Measure search time for 100,000 words
            start = perf_counter()
            for word in searches:
                index.search(word)
            search_seconds = perf_counter() - start

            # Measure sorted index printing time
            output_file = f"{OUT_DIR}/index_{method}_{count}.txt"

            start = perf_counter()
            write_index(output_file, index)
            print_seconds = perf_counter() - start

            # Save the measurements
            rows.append({
                "distinct_words": count,
                "method": method,
                "construction_seconds": build_seconds,
                "search_100000_seconds": search_seconds,
                "printing_seconds": print_seconds,
            })

            print(
                f" build={build_seconds:.2f}s"
                f" search={search_seconds:.2f}s"
                f" print={print_seconds:.2f}s"
            )

    # Save all timing results in a CSV file
    with open(
        "benchmark_results.csv",
        "w",
        newline="",
        encoding="utf-8"
    ) as file:
        writer = csv.DictWriter(file, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)

    # Create three performance graphs
    graphs = [
        (
            "construction_seconds",
            "Construction time (seconds)",
            "construction_time.png",
        ),
        (
            "search_100000_seconds",
            "Search time for 100,000 words (seconds)",
            "search_time.png",
        ),
        (
            "printing_seconds",
            "Sorted printing time (seconds)",
            "printing_time.png",
        ),
    ]

    for metric, label, filename in graphs:
        plt.figure()

        for method in ["trie", "bst", "dict"]:
            values = sorted(
                [row for row in rows if row["method"] == method],
                key=lambda row: row["distinct_words"],
            )

            x_values = [row["distinct_words"] for row in values]
            y_values = [row[metric] for row in values]

            plt.plot(
                x_values,
                y_values,
                marker="o",
                label=method,
            )

        plt.xlabel("Number of distinct words")
        plt.ylabel(label)
        plt.title(label)
        plt.legend()
        plt.grid(True)
        plt.tight_layout()
        plt.savefig(filename)
        plt.close()

    print("\nFinished successfully!")
    print("Check benchmark_results.csv for timing results.")
    print("Check construction_time.png, search_time.png,")
    print("and printing_time.png for the three graphs.")


if __name__ == "__main__":
    main()