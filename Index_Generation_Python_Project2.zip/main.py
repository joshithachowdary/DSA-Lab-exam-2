"""Index Generation: Trie, BST, and dictionary implementations."""
import argparse
from time import perf_counter

SEPARATORS = set(" \t\r\n\f\v.,:;")


def split_words(line):
    words, current = [], []
    for char in line:
        if char in SEPARATORS:
            if current:
                words.append("".join(current))
                current = []
        else:
            current.append(char)
    if current:
        words.append("".join(current))
    return words


class TrieNode:
    def __init__(self):
        self.children = {}
        self.lines = None


class TrieIndex:
    def __init__(self):
        self.root = TrieNode()

    def add(self, word, line):
        node = self.root
        for char in word:
            if char not in node.children:
                node.children[char] = TrieNode()
            node = node.children[char]
        if node.lines is None:
            node.lines = []
        node.lines.append(line)

    def search(self, word):
        node = self.root
        for char in word:
            if char not in node.children:
                return None
            node = node.children[char]
        return node.lines

    def sorted_items(self):
        result, stack = [], [(self.root, "")]
        while stack:
            node, prefix = stack.pop()
            if node.lines is not None:
                result.append((prefix, node.lines))
            for char in sorted(node.children, reverse=True):
                stack.append((node.children[char], prefix + char))
        return result


class BSTNode:
    def __init__(self, word, line):
        self.word, self.lines = word, [line]
        self.left = self.right = None


class BSTIndex:
    def __init__(self):
        self.root = None

    def add(self, word, line):
        if self.root is None:
            self.root = BSTNode(word, line)
            return
        node = self.root
        while True:
            if word == node.word:
                node.lines.append(line)
                return
            if word < node.word:
                if node.left is None:
                    node.left = BSTNode(word, line)
                    return
                node = node.left
            else:
                if node.right is None:
                    node.right = BSTNode(word, line)
                    return
                node = node.right

    def search(self, word):
        node = self.root
        while node:
            if word == node.word:
                return node.lines
            node = node.left if word < node.word else node.right
        return None

    def sorted_items(self):
        result, stack, node = [], [], self.root
        while stack or node:
            while node:
                stack.append(node)
                node = node.left
            node = stack.pop()
            result.append((node.word, node.lines))
            node = node.right
        return result


class DictionaryIndex:
    def __init__(self):
        self.words = {}

    def add(self, word, line):
        if word not in self.words:
            self.words[word] = []
        self.words[word].append(line)

    def search(self, word):
        return self.words.get(word)

    def sorted_items(self):
        return [(word, self.words[word]) for word in sorted(self.words)]


INDEX_CLASSES = {"trie": TrieIndex, "bst": BSTIndex, "dict": DictionaryIndex}


def build_index(filename, index):
    with open(filename, "r", encoding="ascii", errors="replace") as file:
        for line_number, line in enumerate(file, 1):
            for word in split_words(line):
                index.add(word, line_number)


def write_index(filename, index):
    with open(filename, "w", encoding="ascii", errors="backslashreplace") as file:
        for word, lines in index.sorted_items():
            file.write(word + "\t" + ", ".join(map(str, lines)) + "\n")


def main():
    parser = argparse.ArgumentParser(description="Build a sorted word index.")
    parser.add_argument("input_file")
    parser.add_argument("output_file")
    parser.add_argument("--method", choices=INDEX_CLASSES, default="dict")
    args = parser.parse_args()

    index = INDEX_CLASSES[args.method]()
    start = perf_counter()
    build_index(args.input_file, index)
    build_time = perf_counter() - start
    start = perf_counter()
    write_index(args.output_file, index)
    print_time = perf_counter() - start

    print("Method:", args.method)
    print("Index written to:", args.output_file)
    print(f"Construction time: {build_time:.6f} seconds")
    print(f"Sorted output time: {print_time:.6f} seconds")


if __name__ == "__main__":
    main()
