INDEX GENERATION PROJECT - PYTHON

Files:
- main.py: implements Trie, Binary Search Tree (BST), and dictionary indexes.
- benchmark.py: creates six large files, measures construction/search/printing, and plots results.
- tests/sample_input.txt: small sample input.
- tests/expected_sample_index.txt: expected output for the sample input.
- DESIGN_EXPLANATION.txt: short design write-up.

Run the sample using the dictionary:
    python main.py tests/sample_input.txt sample_output.txt

Run each version:
    python main.py tests/sample_input.txt trie_output.txt --method trie
    python main.py tests/sample_input.txt bst_output.txt --method bst
    python main.py tests/sample_input.txt dict_output.txt --method dict

The output contains one word per line, followed by a tab and all 1-based line
numbers where the word occurred. Repeated occurrences are preserved.

The benchmark needs Matplotlib:
    python -m pip install matplotlib
    python benchmark.py

WARNING: benchmark.py creates six files with 1,100,000 word occurrences each,
plus output files and graphs. It may take a long time and use considerable disk
space. Run the small sample first.
