"""Generate six large inputs and compare Trie, BST, and dictionary timings."""
import csv
import os
import random
from time import perf_counter
import matplotlib.pyplot as plt
from main import INDEX_CLASSES, build_index, write_index

COUNTS = [1000, 5000, 10000, 50000, 100000, 500000]
TOTAL_WORDS = 1_100_000
OUT_DIR = "benchmark_data"


def make_word(number):
    return "word" + str(number).zfill(6)


def generate_file(filename, distinct_count):
    rng = random.Random(42 + distinct_count)
    words = [make_word(i) for i in range(distinct_count)]
    with open(filename, "w", encoding="ascii") as file:
        batch = []
        for _ in range(TOTAL_WORDS):
            batch.append(rng.choice(words))
            if len(batch) == 1000:
                file.write(" ".join(batch) + "\n")
                batch = []
        if batch:
            file.write(" ".join(batch) + "\n")


def main():
    os.makedirs(OUT_DIR, exist_ok=True)
    rows = []
    rng = random.Random(42)

    for count in COUNTS:
        input_file = f"{OUT_DIR}/words_{count}.txt"
        print("Generating", input_file)
        generate_file(input_file, count)
        possible_words = [make_word(i) for i in range(count)]
        searches = [rng.choice(possible_words) for _ in range(100_000)]

        for method, cls in INDEX_CLASSES.items():
            print("Testing", method, "with", count, "distinct words")
            index = cls()
            start = perf_counter()
            build_index(input_file, index)
            build_seconds = perf_counter() - start

            start = perf_counter()
            for word in searches:
                index.search(word)
            search_seconds = perf_counter() - start

            output_file = f"{OUT_DIR}/index_{method}_{count}.txt"
            start = perf_counter()
            write_index(output_file, index)
            print_seconds = perf_counter() - start

            rows.append({
                "distinct_words": count,
                "method": method,
                "construction_seconds": build_seconds,
                "search_100000_seconds": search_seconds,
                "printing_seconds": print_seconds,
            })
            print(f" build={build_seconds:.2f}s search={search_seconds:.2f}s print={print_seconds:.2f}s")

    with open("benchmark_results.csv", "w", newline="", encoding="utf-8") as file:
        writer = csv.DictWriter(file, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)

    for metric, label, filename in [
        ("construction_seconds", "Construction time (seconds)", "construction_time.png"),
        ("search_100000_seconds", "Search time for 100,000 words (seconds)", "search_time.png"),
        ("printing_seconds", "Sorted printing time (seconds)", "printing_time.png"),
    ]:
        plt.figure()
        for method in ["trie", "bst", "dict"]:
            values = sorted([r for r in rows if r["method"] == method],
                            key=lambda r: r["distinct_words"])
            plt.plot([r["distinct_words"] for r in values],
                     [r[metric] for r in values], marker="o", label=method)
        plt.xlabel("Number of distinct words")
        plt.ylabel(label)
        plt.title(label)
        plt.legend()
        plt.grid(True)
        plt.tight_layout()
        plt.savefig(filename)
        plt.close()
    print("Finished. See benchmark_results.csv and the three PNG graphs.")


if __name__ == "__main__":
    main()
